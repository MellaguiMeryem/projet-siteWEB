import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class PanierService {
  panier: any[] = [];

  addToCart(product: any): void {
    const existingProduct = this.panier.find(item => item.titre === product.titre);
    if (existingProduct) {
      existingProduct.quantite++;
    } else {
      this.panier.push({ ...product, quantite: 1 });
    }
  }

  removeFromCart(product: any): void {
    const index = this.panier.indexOf(product);
    if (index > -1) {
      this.panier.splice(index, 1);
    }
  }

  getTotalPrice(): number {
    return this.panier.reduce((total, product) => total + (product.price * product.quantite), 0);
  }
}
