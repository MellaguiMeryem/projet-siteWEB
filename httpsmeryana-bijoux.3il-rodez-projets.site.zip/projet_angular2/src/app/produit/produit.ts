import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductService, Product } from '../product.service';
import { CartService } from '../cart.service';
import { BehaviorSubject, combineLatest, map, Observable } from 'rxjs';

@Component({
  selector: 'app-produit',
  imports: [CommonModule],
  templateUrl: './produit.html',
  styleUrl: './produit.css',
})
export class Produit {
  private readonly searchTerm = new BehaviorSubject<string>('');
  readonly categoryFilter = new BehaviorSubject<string>('Tous');

  categories = ['Tous', 'Colliers', 'Bracelets', 'Bagues', 'Boucles d’oreilles'];
  products$!: Observable<Product[]>;
  filteredProducts$!: Observable<Product[]>;

  constructor(
    private readonly productService: ProductService,
    private readonly cartService: CartService
  ) {
    this.products$ = this.productService.getProducts();

    this.filteredProducts$ = combineLatest([
      this.products$,
      this.searchTerm,
      this.categoryFilter
    ]).pipe(
      map(([products, search, category]) => products.filter(product => {
        const query = search.trim().toLowerCase();
        const matchesCategory = category === 'Tous' || product.category === category;
        const matchesSearch = !query || [product.titre, product.description, product.category]
          .some(field => field.toLowerCase().includes(query));
        return matchesCategory && matchesSearch;
      }))
    );
  }

  setSearch(value: string): void {
    this.searchTerm.next(value);
  }

  setCategory(category: string): void {
    this.categoryFilter.next(category);
  }

  addToCart(product: Product): void {
    this.cartService.addToCart(product).subscribe();
  }
}

