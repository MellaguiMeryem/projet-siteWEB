import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CartService, CartItem } from '../cart.service';

@Component({
  selector: 'app-panier',
  imports: [CommonModule],
  templateUrl: './panier.html',
  styleUrl: './panier.css',
})
export class Panier {
  constructor(public readonly cartService: CartService) {}

  get cart$() {
    return this.cartService.cart$;
  }

  get total$() {
    return this.cartService.total$;
  }

  removeFromCart(item: CartItem): void {
    this.cartService.removeFromCart(item._id).subscribe();
  }

  updateQuantity(item: CartItem, delta: number): void {
    const nextQuantity = item.quantite + delta;
    this.cartService.updateQuantity(item._id, nextQuantity).subscribe();
  }

  clearCart(): void {
    this.cartService.clearCart().subscribe();
  }
}
