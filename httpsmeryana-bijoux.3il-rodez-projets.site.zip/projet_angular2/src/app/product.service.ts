import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, catchError, of } from 'rxjs';

export interface Product {
  _id?: string;
  titre: string;
  description: string;
  price: number;
  imageUrl: string;
  category: string;
}

const defaultProducts: Product[] = [
  {
    titre: 'Collier Lumière d’Or',
    description: 'Un collier délicat en plaqué or avec pendentif cristal, parfait pour les occasions élégantes.',
    price: 3280.0,
    imageUrl: '/assets/images/col.png',
    category: 'Colliers'
  },
  {
    titre: 'Bracelet Étoile',
    description: 'Bracelet raffiné en argent avec détail d’étoile scintillante et fermoir ajustable.',
    price: 79.99,
    imageUrl: '/assets/images/bracler.png',
    category: 'Bracelets'
  },
  {
    titre: 'Bague Perle Royale',
    description: 'Bague élégante ornée d’une perle blanche nacrée, montée sur anneau doré fin.',
    price: 99.0,
    imageUrl: '/assets/images/bague.png',
    category: 'Bagues'
  },
  {
    titre: 'Boucles d’oreilles Diamant',
    description: 'Boucles d’oreilles pendantes avec finition brillante et éclat subtil.',
    price: 2438.0,
    imageUrl: '/assets/images/boucle.png',
    category: 'Boucles d’oreilles'
  }
];

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  private readonly apiUrl = '/api/products';

  constructor(private readonly http: HttpClient) {}

  getProducts(): Observable<Product[]> {
    return this.http.get<Product[]>(`${this.apiUrl}/seed`).pipe(
      catchError(() => of(defaultProducts))
    );
  }
}
