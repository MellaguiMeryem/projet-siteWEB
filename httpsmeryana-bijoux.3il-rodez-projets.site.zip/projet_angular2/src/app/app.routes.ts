import { Routes } from '@angular/router';
import { Home } from './home';
import { Produit } from './produit/produit';
import { Panier } from './panier/panier';

export const routes: Routes = [
  { path: 'accueil', component: Home },
  { path: 'produits', component: Produit },
  { path: 'panier', component: Panier },
  { path: '', redirectTo: '/accueil', pathMatch: 'full' }
];