import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, of, catchError, map, tap } from 'rxjs';
import { Product } from './product.service';

export interface CartItem {
  _id: string;
  produitId: string;
  titre: string;
  imageUrl: string;
  price: number;
  quantite: number;
}

@Injectable({
  providedIn: 'root'
})
export class CartService {
  private readonly apiUrl = '/api/cart/';
  private readonly cartSubject = new BehaviorSubject<CartItem[]>([]);
  private localCart: CartItem[] = [];

  cart$ = this.cartSubject.asObservable();
  total$ = this.cart$.pipe(
    map(items => items.reduce((sum, item) => sum + item.price * item.quantite, 0))
  );

  constructor(private readonly http: HttpClient) {
    this.loadCart();
  }

  private nextCart(items: CartItem[]): void {
    this.localCart = items;
    this.cartSubject.next(items);
  }

  private addToLocalCart(payload: Omit<CartItem, '_id'> & { _id?: string }): CartItem {
    const existing = this.localCart.find(item => item.produitId === payload.produitId);
    if (existing) {
      existing.quantite += payload.quantite;
      this.nextCart([...this.localCart]);
      return existing;
    }

    const item: CartItem = {
      _id: payload._id ?? `${payload.produitId}-${Date.now()}`,
      ...payload
    };
    this.nextCart([...this.localCart, item]);
    return item;
  }

  loadCart(): void {
    this.http.get<CartItem[]>(this.apiUrl).pipe(
      catchError(() => of(this.localCart))
    ).subscribe(items => this.nextCart(items));
  }

  addToCart(product: Product): Observable<CartItem> {
    const payload = {
      produitId: product._id ?? product.titre,
      titre: product.titre,
      imageUrl: product.imageUrl,
      price: product.price,
      quantite: 1
    };

    return this.http.post<CartItem>(this.apiUrl, payload).pipe(
      catchError(() => of(this.addToLocalCart(payload))),
      tap(() => this.loadCart())
    );
  }

  updateQuantity(itemId: string, quantite: number): Observable<CartItem | void> {
    if (quantite <= 0) {
      return this.removeFromCart(itemId);
    }

    return this.http.patch<CartItem>(`${this.apiUrl}/${itemId}`, { quantite }).pipe(
      catchError(() => {
        const existing = this.localCart.find(item => item._id === itemId);
        if (existing) {
          existing.quantite = quantite;
          this.nextCart([...this.localCart]);
        }
        return of(existing as CartItem);
      }),
      tap(() => this.loadCart())
    );
  }

  removeFromCart(itemId: string): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${itemId}`).pipe(
      catchError(() => {
        this.nextCart(this.localCart.filter(item => item._id !== itemId));
        return of(void 0);
      }),
      tap(() => this.loadCart())
    );
  }

  clearCart(): Observable<void> {
    return this.http.delete<void>(this.apiUrl).pipe(
      catchError(() => {
        this.nextCart([]);
        return of(void 0);
      }),
      tap(() => this.loadCart())
    );
  }
}
