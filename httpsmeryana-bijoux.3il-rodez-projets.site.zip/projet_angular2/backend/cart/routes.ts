import { Router } from 'express';
import CartItem from './models/cart-item.model';

const router = Router();

router.get('/', async (req, res) => {
  const items = await CartItem.find().lean();
  res.json(items);
});

router.post('/', async (req, res) => {
  const { produitId, titre, imageUrl, price, quantite = 1 } = req.body;
  let item = await CartItem.findOne({ produitId });

  if (item) {
    item.quantite += quantite;
    await item.save();
  } else {
    item = new CartItem({ produitId, titre, imageUrl, price, quantite });
    await item.save();
  }

  res.status(201).json(item);
});

router.patch('/:id', async (req, res) => {
  const { quantite } = req.body;
  const item = await CartItem.findById(req.params.id);

  if (!item) {
    res.status(404).json({ message: 'Article introuvable' });
    return;
  }

  item.quantite = Math.max(1, quantite);
  await item.save();
  res.json(item);
});

router.delete('/:id', async (req, res) => {
  const item = await CartItem.findByIdAndDelete(req.params.id);

  if (!item) {
    res.status(404).json({ message: 'Article introuvable' });
    return;
  }

  res.json(item);
});

router.delete('/', async (req, res) => {
  await CartItem.deleteMany({});
  res.status(204).send();
});

export = router;
