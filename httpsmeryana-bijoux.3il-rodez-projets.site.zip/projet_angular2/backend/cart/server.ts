import express = require('express');
import cors = require('cors');
import { connectDatabase } from '../shared/db';
import cartRoutes = require('./routes');

const app = express();
const port = Number(process.env['PORT'] || 8000);

app.use(cors());
app.use(express.json());
app.use('/cart', cartRoutes);

async function start() {
  await connectDatabase('sap_shop');
  app.listen(port, () => {
    console.log(`Service Panier démarré sur http://localhost:${port}`);
  });
}

start().catch(error => {
  console.error('Impossible de démarrer le service Panier', error);
});
