import mongoose from 'mongoose';

const cartItemSchema = new mongoose.Schema(
  {
    produitId: { type: String, required: true },
    titre: { type: String, required: true },
    imageUrl: { type: String, required: true },
    price: { type: Number, required: true },
    quantite: { type: Number, default: 1 }
  },
  { timestamps: true }
);

const CartItem = mongoose.model('CartItem', cartItemSchema);
export default CartItem;
