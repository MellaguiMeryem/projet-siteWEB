import { Router } from 'express';
import Product from './models/product.model';
import { initialProducts } from './data';

const router = Router();

router.get('/', async (req, res) => {
  const products = await Product.find().lean();
  res.json(products);
});

router.get('/seed', async (req, res) => {
  const count = await Product.countDocuments();
  if (count === 0) {
    await Product.create(initialProducts);
  }
  const products = await Product.find().lean();
  res.json(products);
});

router.post('/', async (req, res) => {
  const product = new Product(req.body);
  await product.save();
  res.status(201).json(product);
});

export = router;
