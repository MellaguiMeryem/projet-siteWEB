export const initialProducts = [
  {
    titre: 'Collier Lumière d’Or',
    description: 'Collier délicat en plaqué or avec pendentif cristal, idéal pour une allure chic.',
    price: 129.0,
    category: 'Colliers',
    imageUrl: '/assets/images/col.png'
  },
  {
    titre: 'Bracelet Étoile',
    description: 'Bracelet raffiné en argent avec motif étoile scintillant.',
    price: 79.0,
    category: 'Bracelets',
    imageUrl: '/assets/images/bracler.png'
  },
  {
    titre: 'Bague Perle Royale',
    description: 'Bague élégante ornée d’une perle nacrée sur anneau doré fin.',
    price: 99.0,
    category: 'Bagues',
    imageUrl: '/assets/images/bague.png'
  },
  {
    titre: 'Boucles d’oreilles Diamant',
    description: 'Boucles d’oreilles pendantes aux reflets subtils pour une touche glamour.',
    price: 149.0,
    category: 'Boucles d’oreilles',
    imageUrl: '/assets/images/boucle.png'
  }
];
