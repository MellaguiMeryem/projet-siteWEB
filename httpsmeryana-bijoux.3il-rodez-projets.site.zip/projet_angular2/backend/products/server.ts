import express = require('express');
import cors = require('cors');
import { connectDatabase } from '../shared/db';
import productRoutes = require('./routes');

const app = express();
const port = Number(process.env['PORT'] || 8080);

app.use(cors());
app.use(express.json());
app.use('/products', productRoutes);

async function start() {
  await connectDatabase('sap_shop');
  app.listen(port, () => {
    console.log(`Service Produits démarré sur http://localhost:${port}`);
  });
}

start().catch(error => {
  console.error('Impossible de démarrer le service Produits', error);
});
