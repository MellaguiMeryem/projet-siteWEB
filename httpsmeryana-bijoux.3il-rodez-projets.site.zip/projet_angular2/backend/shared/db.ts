import mongoose from 'mongoose';

export async function connectDatabase(dbName: string): Promise<void> {
  const mongoUrl = process.env['MONGO_URL'] || 'mongodb://127.0.0.1:27017';
  await mongoose.connect(`${mongoUrl}/${dbName}?authSource=admin`);
}
